#!/bin/Rscript

#computational packages
library('bigmemory')
library('foreach')
#library('parallel')
library('doParallel')

#regresssion packages
library('MASS')
library('pls')

#analysis packages
library('ggplot2')
library('KEGGREST')
library('STRINGdb')
library('lawstat')
#library('biomaRt')
#system(paste("taskset -p 0xff", Sys.getpid()) )

PheLiM <- function(phenotypes, clusters, intmatrix, expressed="noexpression", ncores=1, nfit=30) {

	if(nfit<2) {
		stop("nfit>1 is required")
	}

        phenotypefile <- phenotypes
        if( file.access(phenotypefile,mode=4) ){
                stop(paste(phenotypefile,"can't be read"))
        }
        cat(paste("[Phenotype file]: ",phenotypefile,"\n",sep=''))
	#phenotypetableraw <- read.table(phenotypefile, header=FALSE)
	#colnames(phenotypetableraw) <- c("siRNA","phen")
	#phenotypetable <- aggregate(. ~ siRNA,data=phenotypetableraw,FUN=mean)
	#phenotypetable <- phenotypetable[which(!is.na(phenotypetable[,2])),]
	#sirna <- phenotypetable$siRNA
	#phenotypevector <- phenotypetable$phen


        sirnaclustersfile <- clusters
        if( file.access(sirnaclustersfile,mode=4) ){
                stop(paste(sirnaclustersfile,"can't be read"))
        }
        cat(paste("[Clustered siRNAs]: ",sirnaclustersfile,"\n",sep=''))
	#cluster <- scan(sirnaclustersfile,what=character())
	#numberofcluster <- length(cluster)
	#allsiRNA <- 1:numberofcluster


        noexpression <- FALSE
	expressedfile <- expressed
        if(expressedfile=="noexpression") {
                noexpression <- TRUE
                cat("[Expression file]: no expression file\n")
        } else if( file.access(expressedfile,mode=4) ){
                stop(paste(expressedfile,"can't be read"))
        } else {
                cat(paste("[Expression file]: ",expressedfile,"\n",sep=''))
        }

	#for parallel computation
        cl <- makeCluster(ncores)
        registerDoParallel(cl,cores=ncores)

	#precomputation of matrix
        matrixinteractionfile <- intmatrix
        if( file.access(matrixinteractionfile,mode=4) ){
                stop(paste(matrixinteractionfile,"can't be read"))
        }
        cat(paste("[Interaction matrix]: ",matrixinteractionfile,"\n",sep=''))
	#Loading matrix elements
        cat("\nLoading interaction matrix ... ")
        #tempmatrix <- read.table(matrixinteractionfile,header=TRUE)
	#t <- as.matrix(tempmatrix[,2:ncol(tempmatrix)])
	#rownames(t) <- as.character(tempmatrix[,1])
	#colnames(t) <- colnames( tempmatrix[,2:ncol(tempmatrix)] )
	#rm(tempmatrix)
	t <- as.matrix( read.table(matrixinteractionfile,header=TRUE,row.names=1, as.is=TRUE) )

	cat("done\nSubmatrix over the cutoff ... ")
	cutoff <- 1
        #sirnapertranscript <- parSapply(cl, colnames(t), FUN=function(x)( length( which(t[,x]!=0) ) ) , t )
	sirnapertranscript <- sapply(colnames(t), FUN=function(x)( length( which(t[,x]!=0) ) ) )
	sptselected <- colnames(t[,sirnapertranscript>=cutoff])

	if(!noexpression) {
		cat("done\nLoading most expressed transcript ... ")
		genetranscripttable <- read.table(expressedfile,header=FALSE)
		genenames <- make.names(genetranscripttable[,1])
		sptselected <- sptselected[which(sptselected %in% genenames)]
		cat("done\n")
	} 

	st <- which(colnames(t) %in% sptselected)
	cat("done\nGenerating big.matrix ... ")
	t <- t[,st]
	options(bigmemory.allow.dimnames=TRUE)
	matrixtable <- as.big.matrix( t, type = "double", separated = FALSE, backingfile = "bigmatrix.bin", descriptorfile = "bigmatrix.desc")
	#colnames(matrixtable) <- colnames( tempmatrix[,2:ncol(tempmatrix)] )
	#rownames(matrixtable) <- as.character(tempmatrix[,1])
	rm(t)
	rm(matrixtable)
	cat("done\n")
	gc(verbose=FALSE)

	#writeLines(c(""), "log.txt")
	#cl <- makeCluster(ncores)
	#cl <- makeCluster(ncores)
	registerDoParallel(cores=ncores)
	#registerDoParallel(ncores)
	#sink("log.txt",append=TRUE)
	cat("\nFitting and randomization ... ")
	output <- foreach(nfor=1:nfit, .combine='data.frame', .inorder=FALSE, .packages=c('pls','bigmemory'), .verbose=FALSE) %dopar% {
			#sink("log.txt",append=TRUE)			
			cat(paste("Script",nfor,"running\n"))
			phenotypetableraw <- read.table(phenotypefile, header=FALSE)
			colnames(phenotypetableraw) <- c("siRNA","phen")
			phenotypetable <- aggregate(. ~ siRNA,data=phenotypetableraw,FUN=mean)

			phenotypetable <- phenotypetable[which(!is.na(phenotypetable[,2])),]
			sirna <- phenotypetable$siRNA
			phenotypevector <- phenotypetable$phen
#cat("debug1\n")
			#randomizing clusters 
			cluster <- scan(sirnaclustersfile,what=character())
			numberofcluster <- length(cluster)
			allsiRNA <- 1:numberofcluster
#cat("debug2\n")
			str <- sample(1:numberofcluster,numberofcluster/2, replace=FALSE)
			ste <- allsiRNA[! allsiRNA %in% str]

			seltr <- c()
			for(j in str) {
				t <- strsplit(substring(cluster[j],2),split="|",fixed=TRUE)[[1]]
				seltr <- c(seltr, t)
			}
			trainingsirna <- phenotypetable$siRNA[phenotypetable$siRNA %in% seltr]

			selte <- c()
			for(j in ste) {
				t <- strsplit(substring(cluster[j],2),split="|",fixed=TRUE)[[1]]
				selte <- c(selte, t)
			}
			testingsirna <- phenotypetable$siRNA[phenotypetable$siRNA %in% selte]
#cat("debug3\n")
			#Loading matrix elements
			#cat("Loading pivoted table ... ")
			matrixtable <- attach.big.matrix("bigmatrix.desc")
			siRNAcast <- rownames(matrixtable)
			transcriptcast <- colnames(matrixtable) 
#cat("debug4\n")
			siRNAtraining <- which(siRNAcast %in% trainingsirna)
			siRNAtesting <- which(siRNAcast %in% testingsirna)
#cat("debug5\n")
			#cat("done\nLoading phenotypes ... ")
			trainingphen <- numeric()
			for(i in siRNAcast[siRNAtraining] ) {
				#print(paste(phenotypetable$siRNA[phenotypetable$siRNA %in% i],i))
				trainingphen <- c(trainingphen, phenotypetable$phen[phenotypetable$siRNA %in% i])
			}
			testingphen <- numeric()
			for(i in siRNAcast[siRNAtesting] ) {
				#print(paste(phenotypetable$siRNA[phenotypetable$siRNA %in% i],i))
				testingphen <- c(testingphen, phenotypetable$phen[phenotypetable$siRNA %in% i])
			}
#cat("debug6\n")
			t <- transcriptcast
			ptrain <- trainingphen
			ptest <- testingphen
			#trainingx <- matrixtable[siRNAtraining,]
			dftrain <- data.frame(cbind(ptrain, matrixtable[siRNAtraining,]))
			#rm(trainingx)
                        colnames(dftrain) <- c("phenotype",t)
			#testingx <- matrixtable[siRNAtesting,]
                        dftest <- data.frame(cbind(ptest, matrixtable[siRNAtesting,]))
			#rm(testingx)
                        colnames(dftest) <- c("phenotype",t)
			rm(matrixtable)
			gc(verbose=FALSE)
#print(dim(dftrain))
#cat("debug7\n")
			#cat("done\nPartial least squares ... ")
			ncomponents <- 30
#print("ok")
			plsrres <- plsr(phenotype ~ ., data=dftrain, ncomp=ncomponents, scale=FALSE)
#print("ok")
			rm(dftrain)
#print("ok")
			gc(verbose=FALSE)
			#cat("done\n")
#cat("debug8\n")
			#cat("Selecting the number of components ... ")
			predtesting <- predict(plsrres,dftest,ncomp=1:ncomponents,type="response")
			bestcomp <- which.max(cor(predtesting[,1,],ptest))
			rm(dftest)
			gc(verbose=FALSE)
			#cat(paste("done\nBest ncomp:",bestcomp))
#cat("debug10\n")
			transcriptcontribution <- as.numeric(plsrres$coefficients[ ,1, bestcomp ])
			#cat("\n")
#cat("debug11\n")
			tablefit <- data.frame(transcriptcontribution)
			rownames(tablefit) <- sub("X","",t)
			cat(paste("Script",nfor,"done\n"))
			tablefit
                }
	#sink()
        #stopCluster(cl)
	cat(" done\nDelete temporary matrix ...")
	unlink(c("bigmatrix.desc","bigmatrix.bin"))
	cat(" done\nOutput ...")
        model <- apply(output,1,function(x)( mean(x) ))
        tstatistic <- apply(output,1,function(x)( t.test(x,mu=0)$statistic ))
        pvalue <- apply(output,1,function(x)( t.test(x,mu=0)$p.value ))
        table <- data.frame(gene=rownames(output),model=model,tvalue=tstatistic,pvalue=pvalue)
	rownames(table) <- c()
        outlist <- list(rawcontributions=output, contributions=table)
	cat(" ok\n")
        return(outlist)
}

STRINGtop <- function(contributions, ntop, type=c("inhibitors","enhancers","top")) {
	type <- match.arg(type)
	string_db <- STRINGdb$new( version="10", species=9606, score_threshold=0, input_directory="" )
	df <- contributions[,c("gene","model")]
        colnames(df) <- c("geneid","score")
        if(type=="top") {
		firstn <- as.integer(head(df[order(abs(df$score),decreasing=TRUE),1], ntop) )
	} else if(type=="inhibitors") {
		firstn <- as.integer(head(df[order(df$score,decreasing=TRUE),1], ntop) )
	} else if(type=="enhancers") {
		firstn <- as.integer(tail(df[order(df$score,decreasing=TRUE),1], ntop) )
	} else {
		stop("invalid type option")
	}
	stringids <- string_db$mp(firstn)
	string_db$plot_network(stringids)
}

variancetest <- function(contributions, biomartid=c('entrezgene')) {
	
	df <- contributions[,c("gene","model")]
	colnames(df) <- c("geneid","score")
	KEGGterms <- rev(names(keggList("pathway", "hsa")))
	KEGGGSA <- data.frame(id = character(), varratio = numeric(), mediandevvalue = numeric(), LBFtest = numeric(), name = character())
	for( i in KEGGterms) {
		pathgenes <- keggLink(i)[,2]
		pathgenes <- pathgenes[grep("hsa:",pathgenes)]
		gene.data <- as.integer(lapply( pathgenes ,FUN=function(x) ( strsplit(x,split=":",fixed=T)[[1]][[2]] ) ))
		#print(paste(as.integer(gene.data)))
		if( length(gene.data)>3 ) {
		        entrezgenes <- as.integer(gene.data)
		        tableentrezscorePATH <- df[which( df$geneid %in% entrezgenes ),]
		        tableentrezscorePATH <- tableentrezscorePATH[!is.na(tableentrezscorePATH$score),]
		        tableentrezscoreNOPATH <- df[which( !(df$geneid %in% entrezgenes) ),]
		        tableentrezscoreNOPATH <- tableentrezscoreNOPATH[!is.na(tableentrezscoreNOPATH$score),]
		        if(nrow(tableentrezscorePATH)>3) {
				sdratio <- sd(tableentrezscorePATH$score,na.rm=TRUE)/sd(tableentrezscoreNOPATH$score,na.rm=TRUE)
		                mediandevvalue <- mad(tableentrezscorePATH$score,na.rm=TRUE)/mad(tableentrezscoreNOPATH$score,na.rm=TRUE)
		                LBFtest <- levene.test(c(tableentrezscoreNOPATH$score,tableentrezscorePATH$score), c(rep(1, length(tableentrezscoreNOPATH$score)), rep(2,length(tableentrezscorePATH$score)) ))$p.value
		                id <- i
                                name <- sub(" - Homo sapiens (human)","",keggGet(i)[[1]]$NAME, fixed=TRUE)
 		                KEGGGSA <- rbind(KEGGGSA,data.frame(id,sdratio=log(sdratio), mediandevvalue,LBFtest,name))
		                #cat(paste(id,varratio, mediandevvalue,LBFtest,name,"\n", sep="\t") ) 
		        }
		        #GOGSA <- rbind(GOGSA, c(i,entrezgenes))
		}
	}

	#KEGGGSA$LBFtest <- p.adjust(KEGGGSA$LBFtest,method="fdr")

	#highlight.path <- c("path:hsa04350")

	KEGGGSA <- KEGGGSA[order(KEGGGSA$sdratio,decreasing=T),]
	highlight.path <- head(KEGGGSA$id,20)

	KEGGGSA$highlight <- ifelse((KEGGGSA$id %in% highlight.path), "highlight", "normal")
	#KEGGGSA$highlight <- ifelse((KEGGGSA$varratio>1.5 & KEGGGSA$LBFtest<0.01), "highlight", "normal")
	textdf <- KEGGGSA[which(KEGGGSA$id %in% highlight.path), ]
	#textdf <- KEGGGSA[which(KEGGGSA$varratio>1.5 & KEGGGSA$LBFtest<0.01), ]
	mycolours <- c("highlight" = "red", "normal" = "grey50")
	myalpha <- c("highlight" = 1, "normal" = 0.35)

	graph <- ggplot(data = KEGGGSA, aes(x = sdratio/sd(sdratio,na.rm=T), y = -log10(LBFtest))) +
		geom_point(size = 5, aes(colour = highlight, alpha = highlight)) +
		scale_color_manual(values = mycolours) +
		scale_alpha_manual(values = myalpha) +
		geom_text(data = textdf, aes(x = sdratio/sd(sdratio,na.rm=T)*0.9, y = -log10(LBFtest)*1.02, label = name, size=0.5)) +
		theme_bw() +
		theme(legend.position="none", axis.text=element_text(size=14), axis.title=element_text(size=16,face="bold"), plot.title=element_text(size=rel(2))) +
		xlab("variance ratio") + ylab("LBF test ( -log10(p-value) )") + ggtitle("Pathway variance test")

	return(list("table"=KEGGGSA, "plot"=graph))
}

stabilityplot <- function(contributions) {
	df <- contributions[,c("model","tvalue")]
	df <- cbind(df,d = densCols(df$model, df$tvalue, colramp = colorRampPalette(c("gray","blue","red","yellow"))) )
	#par(oma=c(0,0,0,0), mar=c(2,2,2,0))
	#comparisonplot( df$model, df$tvalue, histbreaks=50, xlab="model", ylab="t-value", main="Stability plot", xlim=c(1.1*min(df$model),1.1*max(df$model)), ylim=c(1.1*min(df$tvalue),1.1*max(df$tvalue)), cor=TRUE)
	absx <- max(abs(df$model))
	absy <- max(abs(df$tvalue))
	ggplot(df) +
		geom_point(aes(model, tvalue, col = d), size = 2) +
		scale_color_identity() +
		theme_bw() +
		theme(axis.text=element_text(size=14), axis.title=element_text(size=16,face="bold"), plot.title=element_text(size=rel(2))) +
		xlim(-absx*1.1,absx*1.1) + ylim(-absy*1.1,absy*1.1) +
		xlab("contributions") + ylab("t-value") + ggtitle("Stability plot")
}

